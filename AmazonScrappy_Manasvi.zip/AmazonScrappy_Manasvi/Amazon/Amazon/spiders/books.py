# -*- coding: utf-8 -*-
import scrapy

from Amazon.items import AmazonItem


class BooksSpider(scrapy.Spider):
    name = "books"
    allowed_domains = ["https://www.amazon.com/b/ref=s9_acss_bw_cg_BHPCB_1b1_w?node=11913537011"]
    start_urls = ['http://www.amazon.com/b/ref=s9_acss_bw_cg_BHPCB_1b1_w?node=11913537011/']

    def parse(self, response):
        book=response.css(".a-box-group.acswidget-carousel__carousel-container li.a-carousel-card.acswidget-carousel__card")
        books=[]
        i=0
        for bk in book:
            i=i+1
            b1=AmazonItem()
            b1['title']=bk.css('span.a-size-small::text').extract_first()
            books.append(b1)
            if i==5:
                break
        return books
