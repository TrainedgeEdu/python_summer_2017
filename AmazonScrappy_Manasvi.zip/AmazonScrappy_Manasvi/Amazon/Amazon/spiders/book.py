# -*- coding: utf-8 -*-
import scrapy
import pandas  as pd
from Amazon.items import AmazonItem


class BookSpider(scrapy.Spider):
    name = "book"
    allowed_domains = ["https://www.amazon.com"]
    start_urls = ['https://www.amazon.com/s/ref=lp_6960520011_il_ti_stripbooks?rh=n%3A283155%2Cn%3A%212334088011%2Cn%3A%212334119011%2Cn%3A6960520011&ie=UTF8&qid=1496990461&lo=stripbooks','https://www.amazon.com/s/ref=lp_6960520011_pg_2?rh=n%3A283155%2Cn%3A%212334088011%2Cn%3A%212334119011%2Cn%3A6960520011&page=2&ie=UTF8&qid=1497074178&lo=none']

    def parse(self, response):
        book=response.css("ul.s-result-list li")
        books=[]
        for bk in book:
            item=AmazonItem()
            item['title']=bk.css('div div a h2::text').extract_first()
            item['price']=bk.css('div span span span::text').extract_first()
            item['release_date'] = bk.css('div span.a-size-small::text').extract_first()
            item['author'] = bk.css('div span.a-size-small a::text').extract_first()
            item['rating'] = bk.css('a i span::text').extract_first()
            books.append(item)
        #books_df=pd.DataFrame(books)

        return books
