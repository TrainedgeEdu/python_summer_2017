# -*- coding: utf-8 -*-
import scrapy
import pandas as pd

from Amazon.items import AmazonMobile


class MobilesSpider(scrapy.Spider):
    name = "mobiles"
    allowed_domains = ["http://www.amazon.in/s/ref=sr_st?keywords=smartphones"]
    start_urls = ['http://www.amazon.in/s/ref=sr_st?keywords=smartphones&fst=as%3Aon&rh=n%3A976419031%2Cn%3A1389401031%2Cn%3A1389432031%2Cn%3A1805560031%2Ck%3Asmartphones&qid=1496994578&sort=smooth-review-rank']

    def parse(self, response):
        mobile = response.css('ul.s-result-list li')
        mob = []
        for i in mobile:
            item = AmazonMobile()
            item['image_url'] = i.css('div div div a img').xpath('@src').extract_first()
            item['model']=i.css('div div a').xpath('@title').extract_first()
            #x=i.css('div.a-spacing-none span.a-size-small::text').extract()
            #item['brand']=str(x[1])
            item['brand']=i.css('div.a-spacing-none span.a-size-small::text').extract()
            item['rating']=i.css('i.a-icon-star span::text').extract_first()
            item['price']=i.css('div.a-spacing-none a span.s-price::text').extract_first()

            mob.append(item)
        #mobDf=pd.DataFrame(mob)
        #print(mobDf)

        return mob
