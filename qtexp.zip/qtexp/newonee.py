# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'newone.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
s=[]
import sys
class Ui_MainWindow(object):
        def setupUi(self, MainWindow):
            MainWindow.setObjectName("MainWindow")
            MainWindow.resize(800, 600)
            self.centralwidget = QtWidgets.QWidget(MainWindow)
            self.centralwidget.setObjectName("centralwidget")
            self.frame = QtWidgets.QFrame(self.centralwidget)
            self.frame.setGeometry(QtCore.QRect(30, 80, 701, 421))
            self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
            self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
            self.frame.setLineWidth(12)
            self.frame.setMidLineWidth(2)
            self.frame.setObjectName("frame")
            self.label = QtWidgets.QLabel(self.frame)
            self.label.setGeometry(QtCore.QRect(0, 0, 81, 51))
            self.label.setFocusPolicy(QtCore.Qt.StrongFocus)
            self.label.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap(":/icon/expense_manager_72px_1105761_easyicon.net.ico"))
            self.label.setScaledContents(True)
            self.label.setObjectName("label")
            self.textBrowser = QtWidgets.QTextBrowser(self.frame)
            self.textBrowser.setGeometry(QtCore.QRect(80, 0, 271, 51))
            self.textBrowser.setObjectName("textBrowser")
            self.label_3 = QtWidgets.QLabel(self.frame)
            self.label_3.setGeometry(QtCore.QRect(300, 360, 111, 31))
            self.label_3.setFrameShadow(QtWidgets.QFrame.Raised)
            self.label_3.setLineWidth(0)
            self.label_3.setTextFormat(QtCore.Qt.PlainText)
            self.label_3.setScaledContents(True)
            self.label_3.setObjectName("label_3")
            self.pushButton = QtWidgets.QPushButton(self.frame)
            self.pushButton.setGeometry(QtCore.QRect(300, 80, 111, 31))
            self.pushButton.setObjectName("pushButton")
            self.pushButton_2 = QtWidgets.QPushButton(self.frame)
            self.pushButton_2.setGeometry(QtCore.QRect(440, 80, 101, 31))
            self.pushButton_2.setObjectName("pushButton_2")
            self.textBrowser_2 = QtWidgets.QTextBrowser(self.frame)
            self.textBrowser_2.setGeometry(QtCore.QRect(0, 120, 256, 41))
            self.textBrowser_2.setObjectName("textBrowser_2")
            self.textBrowser_3 = QtWidgets.QTextBrowser(self.frame)
            self.textBrowser_3.setGeometry(QtCore.QRect(300, 120, 256, 41))
            self.textBrowser_3.setObjectName("textBrowser_3")
            self.listWidget = QtWidgets.QListWidget(self.frame)
            self.listWidget.setGeometry(QtCore.QRect(0, 160, 256, 192))
            self.listWidget.setObjectName("listWidget")
            self.listWidget_2 = QtWidgets.QListWidget(self.frame)
            self.listWidget_2.setGeometry(QtCore.QRect(300, 160, 256, 192))
            self.listWidget_2.setObjectName("listWidget_2")
            self.plainTextEdit = QtWidgets.QPlainTextEdit(self.frame)
            self.plainTextEdit.setGeometry(QtCore.QRect(10, 70, 104, 41))
            self.plainTextEdit.setObjectName("plainTextEdit")
            self.plainTextEdit_2 = QtWidgets.QPlainTextEdit(self.frame)
            self.plainTextEdit_2.setGeometry(QtCore.QRect(130, 70, 104, 41))
            self.plainTextEdit_2.setObjectName("plainTextEdit_2")
            self.textBrowser_4 = QtWidgets.QTextBrowser(self.frame)
            self.textBrowser_4.setGeometry(QtCore.QRect(20, 360, 211, 41))
            self.textBrowser_4.setObjectName("textBrowser_4")
            MainWindow.setCentralWidget(self.centralwidget)
            self.menubar = QtWidgets.QMenuBar(MainWindow)
            self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
            self.menubar.setObjectName("menubar")
            MainWindow.setMenuBar(self.menubar)
            self.statusbar = QtWidgets.QStatusBar(MainWindow)
            self.statusbar.setObjectName("statusbar")
            MainWindow.setStatusBar(self.statusbar)

            self.retranslateUi(MainWindow)
            QtCore.QMetaObject.connectSlotsByName(MainWindow)
            self.pushButton.clicked.connect(self.addText)
            self.pushButton_2.clicked.connect(self.delText)

        def addText(self):
            text1 = self.plainTextEdit.toPlainText()
            text2 = self.plainTextEdit_2.toPlainText()
            if text1 or text2:
                self.listWidget.addItem(text1)
                self.listWidget_2.addItem(text2)
                s.append(int(text2))
                self.label_3.setText(str(sum(s)))
                self.plainTextEdit.clear()
                self.plainTextEdit_2.clear()

        def delText(self):
            text1 = self.plainTextEdit.toPlainText()
            text2 = self.plainTextEdit_2.toPlainText()
            if text1 or text2:
                #self.listWidget.addItem(text1)
                #self.listWidget_2.addItem(text2)
                s.remove(int(text2))
                self.label_3.setText(str(sum(s)))
                self.plainTextEdit.clear()
                self.plainTextEdit_2.clear()

        def retranslateUi(self, MainWindow):
            _translate = QtCore.QCoreApplication.translate
            MainWindow.setWindowTitle(_translate("MainWindow", "GUIAPPLICTION"))
            self.textBrowser.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:22pt; font-style:italic; text-decoration: underline;\">EXPENSE MANAGER</span></p></body></html>"))
            self.label_3.setText(_translate("MainWindow", "TOTAL"))
            self.pushButton.setText(_translate("MainWindow", "ADD ITEMS"))
            self.pushButton_2.setText(_translate("MainWindow", "DELETE ITEMS"))
            self.textBrowser_2.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-style:italic; text-decoration: underline;\">LIST OF ITEMS</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:20pt; font-style:italic; text-decoration: underline;\"><br /></p></body></html>"))
            self.textBrowser_3.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-style:italic; text-decoration: underline;\">PRICE OF ITEMS</span></p></body></html>"))
            self.textBrowser_4.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-style:italic; text-decoration: underline;\">TOTAL SUM</span></p></body></html>"))



if __name__ == "__main__":
        import sys
        app = QtWidgets.QApplication(sys.argv)
        MainWindow = QtWidgets.QMainWindow()
        ui = Ui_MainWindow()
        ui.setupUi(MainWindow)
        MainWindow.show()
        sys.exit(app.exec_())

